input_file = open("input1", 'r')
output_file = open("output1", 'w')

read_lines = input_file.readlines()

interval_list = []

input_count = int(read_lines[0])

for i in range(1, len(read_lines)):
    temporary = read_lines[i].split(' ')

    start = int(temporary[0])
    end = int(temporary[1])

    interval = []
    interval.append(start)
    interval.append(end)
    interval_list.append(interval)

final_list = []

for i in range(len(interval_list)):
    for j in range(len(interval_list) - 1):
        if (interval_list[j][1] > interval_list[j + 1][1]):
            interval_list[j], interval_list[j + 1] = interval_list[j + 1], interval_list[j]

new_list = interval_list
final_list = []
select_list = []
cursor = None

for i in range(len(new_list)):
    if (select_list == []):
        select_list.append(new_list[i])
        cursor = 0
    else:
        if new_list[i][0] >= select_list[cursor][1] and new_list[i][0] > select_list[cursor][0]:
            select_list.append(new_list[i])
            cursor = cursor + 1

output_file.writelines(str(len(select_list)) + '\n')

for z in select_list:
    if len(z) != 1:
        output_file.writelines(str(z[0]) + ' ' + str(z[1]) + '\n')

input_file.close()
output_file.close()
