input_file = open("input2", "r")
output_file = open("output2", "w")
file_content = input_file.readline()
total_jobs, total_people = map(int, file_content.split())
start_time = []
end_time = []

for _ in range(total_jobs):
    line = input_file.readline()
    job_start, job_end = map(int, line.split())
    start_time.append(job_start)
    end_time.append(job_end)

def bubble_sort(arr1, arr2):
    for i in range(len(arr2) - 1):
        for j in range(len(arr2) - i - 1):
            if arr2[j] > arr2[j + 1]:
                arr2[j], arr2[j + 1] = arr2[j + 1], arr2[j]
                arr1[j], arr1[j + 1] = arr1[j + 1], arr1[j]

bubble_sort(start_time, end_time)

def assign_jobs(start_arr, end_arr, person):
    assigned_array = [[start_arr[person - 1], end_arr[person - 1]]]
    ind = 0
    for i in range(person - 1, len(start_arr), 2):
        for j in range(len(end_arr)):
            if start_arr[i] >= end_arr[ind]:
                assigned_array.append([start_arr[i], end_arr[i]])
                ind = i
                break
    return assigned_array

total_work_done = 1
for person in range(1, total_people):
    selected_assignments = assign_jobs(start_time, end_time, person + 1)
    total_work_done += len(selected_assignments)

print(total_work_done)
output_file.write(str(total_work_done))

input_file.close()
output_file.close()
