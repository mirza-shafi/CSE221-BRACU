input_file = open("input3", 'r')
output_file = open("output3", 'w')
input_values = input_file.readline().strip().split(" ")
r1 = list(map(int, input_values))
n = r1[0]
k = r1[1]
sz = [1] * (n + 1)
parent = list(range(n + 1))

def find_parent(pp):
    if parent[pp] != pp:
        parent[pp] = find_parent(parent[pp])
    return parent[pp]

def merge_sets(x, y):
    px = find_parent(x)
    py = find_parent(y)
    if px == py:
        return sz[px]
    if sz[px] < sz[py]:
        px, py = py, px
    parent[py] = px
    sz[px] += sz[py]
    return sz[px]

results = []
for i in range(k):
    a, b = map(int, input_file.readline().split())
    results.append(merge_sets(a, b))

for r in results:
    output_file.write(str(r) + '\n')

output_file.close()
