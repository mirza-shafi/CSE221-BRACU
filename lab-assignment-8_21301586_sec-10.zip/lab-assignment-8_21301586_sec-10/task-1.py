input_file = open("input-1.txt", 'r')
output_file = open("output-1.txt", 'w')

n, m = map(int, input_file.readline().strip().split())
roads = []
for _ in range(m):
    u, v, w = map(int, input_file.readline().strip().split())
    roads.append((u, v, w))


def find_parent(parent, node):
    if parent[node] == node:
        return node
    parent[node] = find_parent(parent, parent[node])
    return parent[node]

def union_sets(parent, rank, u, v):
    u_parent = find_parent(parent, u)
    v_parent = find_parent(parent, v)

    if u_parent != v_parent:
        if rank[u_parent] < rank[v_parent]:
            u_parent, v_parent = v_parent, u_parent
        parent[v_parent] = u_parent
        if rank[u_parent] == rank[v_parent]:
            rank[u_parent] += 1


def minimum_spanning_tree(edges, n):
    edges.sort(key=lambda x: x[2])
    parent = list(range(n + 1))
    rank = [0] * (n + 1)
    mst_cost = 0

    for u, v, w in edges:
        if find_parent(parent, u) != find_parent(parent, v):
            mst_cost += w
            union_sets(parent, rank, u, v)

    return mst_cost


mst_cost = minimum_spanning_tree(roads, n)


max_edge = max(roads, key=lambda x: x[2])

result = mst_cost - max_edge[2]


output_file.write(str(result))

input_file.close()
output_file.close()

