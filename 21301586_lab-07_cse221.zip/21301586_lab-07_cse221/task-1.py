import heapq

def dijkstra(graph, source):
    n = len(graph)
    distances = [float('inf')] * n
    distances[source - 1] = 0
    pq = [(0, source)]

    while pq:
        dist, node = heapq.heappop(pq)
        if dist > distances[node - 1]:
            continue
        
        for neighbor, weight in graph[node]:
            new_dist = dist + weight
            if new_dist < distances[neighbor - 1]:
                distances[neighbor - 1] = new_dist
                heapq.heappush(pq, (new_dist, neighbor))

    return distances

# Read input
N, M = map(int, input().split())
graph = [[] for _ in range(N + 1)]

for _ in range(M):
    u, v, w = map(int, input().split())
    graph[u].append((v, w))

S = int(input())

# Find shortest distances using Dijkstra's algorithm
shortest_distances = dijkstra(graph, S)

# Print output
print(' '.join(str(d) if d != float('inf') else '-1' for d in shortest_distances[1:]))
