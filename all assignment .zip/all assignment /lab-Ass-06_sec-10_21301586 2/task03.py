
import math
from queue import  PriorityQueue

intput_file =  open('input3.txt', "r")
output_file =  open('output3.txt', "w")
r_f= intput_file .readline().split()
dic = {}
store = 1

nodes = int( r_f[0] )
edges = int( r_f[1] )

for a in range (nodes+1) :
  dic . update( {a:[]})
for b in range(edges) :
  r = intput_file .readline().split()
  dic [  int(r[0])].append(( (int(r[2]), int(r[1]) )))


def path (graph,store) :
  
  lst = []
  
  temp=[math.inf]*(nodes+1)
  
  temp[store]= 0
  
  pqueue= PriorityQueue()
  
  pqueue.put((0,store))
  
  edges= 0
 
  while pqueue.empty()== False :
    flag= pqueue.get()
    lst .append(flag[1] )
    
    if(flag[0] < temp[flag[1]]) :
      temp[flag[1]]= flag[0]
    
    for d in graph[flag[1]]:
      edges= max(flag[0],d[0])
      
      if(d[1] not in lst ):
        pqueue.put((edges,d[1]))
  
  return temp[-1]   

output_file.write(path (dic , store) ,file=output_file )
intput_file .close()
output_file .close()