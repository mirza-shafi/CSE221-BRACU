import heapq
inputf = open("input1.txt", "r")
outputf = open("output1.txt", "w")

def Dijkstra(graph, start):

    distances = {node: float('inf') for node in graph} 


    distances[start] = 0

    priority_queue = [(0, start)]


    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        if current_distance > distances[current_node]:
            continue

        for neighbor, weight in graph[current_node]:
            distance = current_distance + weight

            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))

    return distances



inputs = inputf.readline().split(" ")
m = int(inputs[0])
n = int(inputs[1])

adjlist = {}
for i in range(0, m + 1):
    adjlist[i] = []

for j in range(n):
    values = inputf.readline().split(" ")
    a = int(values[0])
    b = int(values[1])
    c = int(values[2])

    adjlist[a].append((b, c))


source =int(inputf.readlines()[-1])
shortest_distances = Dijkstra(adjlist, source)
output=""


for node, distance in shortest_distances.items():
    output=output+" "+ str(distance)
outputf.write(output[5::])



inputf.close()
outputf.close()



