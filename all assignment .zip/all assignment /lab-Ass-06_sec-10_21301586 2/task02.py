import math
from queue import PriorityQueue

input_file = open('input2.txt', 'r')
output_file = open('output2.txt', 'w')

nodes, edge = map(int, input_file.readline().split())

def Dijkstra_algo(source, graph, c):
  
  
  
    lst = [math.inf] * (nodes + 1)

    queue = PriorityQueue()
    
    queue.put((c, source))

    while not queue.empty():
      
        value, source = queue.get()

        if lst[source] > value:
          
            lst[source] = value

            if graph[source] is not None:
              
                for neighbor, up_value in graph[source]:
                  
                    queue.put((up_value + value, neighbor))
            else:
              
                pass
              
        else:
          
            pass

    return lst

def Graph(nodes, edge):
  
    adj_lst = [None] * (nodes + 1)

    for _ in range(edge):
      
        u, v, w = map(int, input_file.readline().split())
        
        if adj_lst[u] is not None:
          
            adj_lst[u].append((v, w))
            
        else:
          
            adj_lst[u] = [(v, w)]
            
    return adj_lst


adj_lst = Graph(nodes, edge)

source, a = map(int, input_file.readline().split())

temp1 = Dijkstra_algo(source, adj_lst, 0)

temp2 = Dijkstra_algo(a, adj_lst, 0)

node = None

total_time = math.inf

for c in range(len(temp1)):
  
    if temp2[c] != math.inf and temp1[c] != math.inf:
      
        store = max(temp2[c], temp1[c])

        if total_time > store:
          
            node = c
            
            total_time = store

if node is not None:
  
    output_file.write('Time', total_time, file=output_file)
    
    output_file.write('Node', node, file=output_file)
    
else:
  
    output_file.write('Impossible', file=output_file)

input_file.close()

output_file.close()