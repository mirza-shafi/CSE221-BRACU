#Task-1(a)
# input_path = "/input.output/input1a.txt"
# output_path = "/input.output/output1a.txt"

output = open("input1a.text", 'w')
f = open("output1a", 'r')
t = int(f.readline())
i = 0
for i in range(t):
    n = int(f.readline())
    if n%2==0:
        k = f'{n} is an Even number.'
        print(k)
        output.write(k)
        output.write("\n")
    else:
        j = f'{n} is an Odd number.'
        print(j)
        output.write(j)
        output.write("\n")
output.close()