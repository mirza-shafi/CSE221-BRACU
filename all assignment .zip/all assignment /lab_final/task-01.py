input_file1 = open("i.txt","r")
output_file1 = open("output.txt","w")

r1 = output_file1.readline().split()
print(r1)