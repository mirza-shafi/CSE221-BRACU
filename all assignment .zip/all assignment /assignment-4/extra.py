input = open("input-1.txt","w")
ouput = open("output-1.txt","w")

n,m = (input.readline().split())

n = int(n)
m = int(m)
matrixs = [[0 for i in range(n+1)]for i in range (m)]
print(n,m)
print(matrixs)