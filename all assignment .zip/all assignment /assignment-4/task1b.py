input_file = open("input_1b.txt","r")
output_file = open("output_1b.txt","w")
n,m = input_file.readline().split()
print(n,m)