f  = open("input1a-1.txt","r")
f2 = open("output1a_1.txt","w")
r1 = list(map(int, f.readline().strip().split(" ")))
print(r1)
# l=[]
# l2=[]
# l3=[]

# for x in range(r1[1]):
#   r2 = list(map(int, f.readline().strip().split(" ")))
#   l.append(r2)
# for y in range(r1[0]+1):
#     l2 = []
#     for y in range(r1[0]+1):
#         l2.append(0)
#     l3.append(l2)
# for z in l:
#   u= z[0]
#   v= z[1]
#   w= z[2]
#   l3[u][v]=w
# for row in l3:
#     for val in row:
#         f2.write(str(val) + " ")
#     f2.write("\n")
# f2.close()