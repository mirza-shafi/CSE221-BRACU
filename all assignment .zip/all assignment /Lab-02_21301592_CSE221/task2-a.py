
inp = open("input2a.txt","r")
oup = open("output2a.txt","w")
k1 = list(map(int,input.readline().strip().split(" ")))
k2 = list(map(int,input.readline().strip().split(" ")))
k3 = list(map(int,input.readline().strip().split(" ")))
k4 = list(map(int,input.readline().strip().split(" ")))
newlistt = k2 + k4
sortedlist=sorted(newlistt)
for x in sortedlist:
  oup.write(str(x)+ " ")
oup.close()