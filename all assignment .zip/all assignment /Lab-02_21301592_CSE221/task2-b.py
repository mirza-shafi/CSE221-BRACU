
inp = open('input2-b.txt','r')
f2 = open('output2-b.txt','w')
k1= list(map(int,input.readline().strip().split(" ")))
k2= list(map(int,input.readline().strip().split(" ")))
k3=list(map(int,input.readline().strip().split(" ")))
k4= list(map(int,input.readline().strip().split(" ")))
l=[]
x=0
y=0
while  x < k1[0] and y < k3[0]:
  if k2[x] <= k4[y]:
    l.append(k2[x])
    x=x+1
  else:
    l.append(k4[y])
    y=y+1
for k in range(x,(k1[0])):
  l.append(k2[k])
for m in range(y,k3[0]):
  l.append(k4[m])
for x in l:
  f2.write(str(x)+" ")
f2.close()