
inp = open('input4.txt','r')
inp = open('output4.txt','w')
r1= list(map(int,input.readline().strip().split(" ")))
arr= list(map(int,input.readline().strip().split(" ")))

def maxValue(arr,l,r):
  if l==r:
    return arr[l]
  else:
    mid=(l+r)//2
    maximumleft= maxValue(arr,l,mid)
    maximumright= maxValue(arr,mid+1,r)
    return maximumleft if maximumleft > maximumright else maximumright
maxvalue=maxValue(arr,0,r1[0]-1)
input.write(str(maxvalue))
input.close()
