
inp = open("input1-a.txt", "r")
outp = open("output1-a.txt", "w")
lst1 = list(map(int, input.readline().strip().split(" ")))
lst2 = list(map(int, input.readline().strip().split(" ")))
total = lst1[1]
l = []
for x in range(lst1[0]):
    for y in range(x + 1,lst1[0]):
        if lst2[x] + lst2[y] == total:
            l.append(x + 1)
            l.append(y + 1)
    break
if len(l) > 0:
    for x in l:
        outp.write(str(x) + " ")
else:
    outp.write("IMPOSSIBLE")

inp.close()
outp.close()
