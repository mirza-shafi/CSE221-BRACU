
inp = open('input3.txt','r')
outp = open('output3.txt','w')
lst1 = list(map(int,input.readline().strip().split(" ")))
lst2 = list(map(int,input.readline().strip().split(" ")))

def merge(a1,a2):
  i=0
  j=0
  idx=0
  sortedarr=[None]*(len(a1)+len(a2))
  while i < len(a1) and j < len(a2):
    if a1[i] < a2[j]:
      sortedarr[idx]=a1[i]
      i+=1
      idx+=1
    else:
      sortedarr[idx]=a2[j]
      j+=1
      idx+=1
  while i < len(a1):
    sortedarr[idx]=a1[i]
    i+=1
    idx+=1
  while j < len(a2):
    sortedarr[idx]=a2[j]
    j+=1
    idx+=1
  return sortedarr

def mergeSort(arr):
  if len(arr)<=1:
    return arr
  else:
    mid=len(arr)//2
    a1=mergeSort(arr[0:mid])
    a2=mergeSort(arr[mid:len(arr)])
    return merge(a1,a2)

sorted=mergeSort(lst2)
for i in range(len(sorted)):
  outp.write(f'{sorted[i]} ')
outp.close()