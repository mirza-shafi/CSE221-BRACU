
inp = open("input1b.txt", "r")
outp = open("output1b.txt", "w")
lst1 = list(map(int, input.readline().strip().split(" ")))
lst2 = list(map(int, input.readline().strip().split(" ")))
total= lst1[1]
l=[]
flag = False
l = {}
for x in range(lst1[0]):
  temp = total - lst2[x]
  if temp in hash:
    flag = True
    l.append((hash[temp], x + 1))
    break
  hash[lst2[x]] =x+1
if flag == True:
  for x in l:
    outp.write(str(x[0]) + " " + str(x[1]) + "\n")
else:
  outp.write("IMPOSSIBLE")
outp.close()