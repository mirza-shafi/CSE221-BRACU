inpf=open("input1.txt","r")
outf=open("output1.txt","w")
n=int(inpf.readline())
arr=list(map(int, inpf.readline().strip().split(" ")))

def merge_sort(arr):
    if len(arr) <= 1:
        return arr, 0

    mid = len(arr) // 2
    left, left_count = merge_sort(arr[:mid])
    right, right_count = merge_sort(arr[mid:])
    merged, merge_count = merge(left, right)
    total_count = left_count + right_count + merge_count
    return merged, total_count


def merge(left, right):
    merged = []
    count = 0
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            count += len(left) - i
            j += 1

    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged, count


N = int(input())
heights = list(map(int, input().split()))
inversions = merge_sort(heights)
print(inversions)