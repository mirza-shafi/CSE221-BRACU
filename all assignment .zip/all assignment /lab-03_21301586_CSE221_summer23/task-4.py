intf = open("input4.txt", "r")
outf = open("output4.txt", "w")
n = intf.readline().split(" ")
n = int(n[0])

arr = list(map(int, intf.readline().strip().split(" ")))
m = intf.readline().split(" ")
que = int(m[0])



def partition(arr, first, last):
    current_pvt = arr[last]
    i = first - 1
    for j in range(first, last):
        if arr[j] <= current_pvt:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[last] = arr[last], arr[i + 1]
    i+=1
    return i


def kth_small(arr, first, last, k):
    if first <= last:
        pvt_idx = partition(arr, first, last)
        if pvt_idx == k - 1:
            return arr[pvt_idx]
        elif pvt_idx > k - 1:
            return kth_small(arr, first, pvt_idx - 1, k)
        else:
            return kth_small(arr, pvt_idx + 1, last, k)


for i in range(que):
    k = int(intf.readline())
    kth = kth_small(arr, 0, n - 1, k)
    outf.write(str(kth) + "\n")
   
outf.close()

