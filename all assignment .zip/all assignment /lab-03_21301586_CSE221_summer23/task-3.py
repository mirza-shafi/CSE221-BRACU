inpf = open("input3.txt", "r")
outf = open("output3.txt", "w")
n = int(inpf.readline())

arr = list(map(int, inpf.readline().strip().split(" ")))

def quicksort(arr, p, r):
    if p < r:
        q = Partition(arr, p, r)
        quicksort(arr, p, q - 1)
        quicksort(arr, q + 1, r)


def Partition(arr, p, r):
    x = arr[r]
    i = p - 1
    for j in range(p, r):
        if arr[j] <= x:
            i = i + 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[r] = arr[r], arr[i + 1]
    i+=1

    return i




quicksort(arr, 0, n - 1)
for i in range(len(arr)):
    outf.write(str(arr[i]) + " ")


outf.close()

