
inpf = open("input2.txt", "r")
outf = open("output2.txt", "w")
n = int(inpf.readline()) 

arr = list(map(int, inpf.readline().strip().split(" ")))
def find_max_sum(arr):
    max_sum = float('-inf')
    max_num = float('-inf')

    for num in nums:
        max_sum = max(max_sum, max_num + num ** 2)
        max_num = max(max_num, num)

    return max_sum


N = int(input())
nums = list(map(int, input().split()))

max_value = find_max_sum(nums)

print(max_value)
