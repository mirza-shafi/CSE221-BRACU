#Task 1(a)
input1 = open('Input1a(iii).txt', 'r')
output1 = open('Output1a(iii).txt', 'w')
N, M = list(map(int, input1.readline().split()))

lst = []
for i in range(M):
    info = list(map(int,input1.readline().split(" ")))
    lst.append(info)

graph = [[] for _ in range(N + 1)]
for y in lst:
    u = y[0]
    v = y[1]
    graph[u].append(v)

y = [False] * (N+1)
stack = []

def dfs(node, graph, y, stack, x):
    x[node] = True
    for nei in graph[node]:
        if x[nei]:
            return False  # Cycle detected
        if not y[nei]:
            if not dfs(nei, graph, y, stack, x):
                return False
    x[node] = False
    y[node] = True
    stack.append(node)
    return True

c = 0
for node in range(1, N+1):
    if not y[node]:
        if not dfs(node, graph, y, stack, [False] * (N+1)):
            c = 1

strr = ''
if c== 1:
    strr='IMPOSSIBLE'
else:
    stack=stack[::-1]
    for i in stack:
        strr += str(i)+' '
output1.write(strr)


input1.close()
output1.close()