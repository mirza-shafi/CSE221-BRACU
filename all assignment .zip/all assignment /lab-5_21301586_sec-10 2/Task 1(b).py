#Task 1(b)
input1a = open('Input1b(iii).txt', 'r')
output1a = open('Output1b(iii).txt', 'w')
N, M = list(map(int, input1a.readline().split()))

lst = []
for i in range(M):
    info = list(map(int,input1a.readline().split(" ")))
    lst.append(info)

graph = [[] for _ in range(N + 1)]
for y in lst:
    u = y[0]
    v = y[1]
    graph[u].append(v)

visited = [False] * (N+1)
InDegree = [0] * (N+1)

for u in range(len(graph)):
    for nei in graph[u]:
        InDegree[nei] += 1

queue = []
for node in range(1, N+1):
    if InDegree[node] == 0:
        queue.append(node)

courseS = []
while queue:
    node = queue.pop(0)
    courseS.append(node)
    visited[node] = True
    for nei in graph[node]:
        InDegree[nei] -= 1
        if InDegree[nei] == 0:
            queue.append(nei)

visited[0]=True

strr = ''
if not all(visited):
    strr='IMPOSSIBLE'
else:
    for i in courseS:
        strr += str(i)+' '
print(strr)
output1a.write(strr)
input1a.close()
output1a.close() 