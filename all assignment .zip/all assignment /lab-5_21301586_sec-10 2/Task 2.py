#Task 2
import heapq

input2 = open('Input2(iii).txt', 'r')
output2 = open('Output2(iii).txt', 'w')
N, M = list(map(int, input2.readline().split()))

lst1 = []
for i in range(M):
    info = list(map(int,input2.readline().split(" ")))
    lst1.append(info)



inDegree = [0] * (N+1)
graph = [[] for _ in range(N + 1)]
for y in lst1:
    u = y[0]
    v = y[1]
    graph[u].append(v)
    inDegree[v] += 1   
    
pq = []
for i in range(1, N+1):
    if inDegree[i] == 0:
        heapq.heappush(pq, i)

courseS = []
while pq:
    course = heapq.heappop(pq)
    courseS.append(course)

    for neighbor in graph[course]:
        inDegree[neighbor] -= 1
        if inDegree[neighbor] == 0:
            heapq.heappush(pq, neighbor)

strr = ''
if len(courseS) < N:
    strr='IMPOSSIBLE'
else:
    for i in courseS:
        strr += str(i)+' '


output2.write(strr)
input2.close()
output2.close()