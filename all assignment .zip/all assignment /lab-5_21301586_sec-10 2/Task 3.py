#Task 3
input3 = open('Input3(iii).txt', 'r')
output3 = open('Output3(iii).txt', 'w')
N, M = list(map(int, input3.readline().split()))

lst1 = []
for i in range(M):
    info = list(map(int,input3.readline().split(" ")))
    lst1.append(info)

graph = [[] for _ in range(N + 1)]
reverse_graph = [[] for _ in range(N + 1)]
for y in lst1:
    u = y[0]
    v = y[1]
    graph[u].append(v)
    reverse_graph[v].append(u)

visited = [False] * (N + 1)
stack = []

def first_dfs(node, graph, visited, stack):
    visited[node] = True
    for nei in graph[node]:
        if not visited[nei]:
            first_dfs(nei, graph, visited, stack)
    stack.append(node)

for node in range(1, N + 1):
    if not visited[node]:
        first_dfs(node, graph, visited, stack)

def second_dfs(node, reverse_graph, visited, component):
    visited[node] = True
    component.append(node)
    for nei in reverse_graph[node]:
        if not visited[nei]:
            second_dfs(nei, reverse_graph, visited, component)

visited = [False] * (N + 1)
S_C_C = []

while stack:
    node = stack.pop()
    if not visited[node]:
        component = []
        second_dfs(node, reverse_graph, visited, component)
        S_C_C.append(component)

for component in S_C_C:
    strr = ''
    for i in component:
        strr += str(i)+' '
    output3.write(strr+'\n')

input3.close()
output3.close()