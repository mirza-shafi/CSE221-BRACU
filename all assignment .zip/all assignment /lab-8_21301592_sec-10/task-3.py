input_file = open("input-3.txt", 'r')
output_file = open("output-3.txt", 'w')


N, X = map(int, input_file.readline().strip().split())

coins = list(map(int, input_file.readline().strip().split()))


def minCoins(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0

    for coin in coins:
        for i in range(coin, amount + 1):
            dp[i] = min(dp[i], dp[i - coin] + 1)

    return dp[amount] if dp[amount] != float('inf') else -1

result = minCoins(coins, X)


output_file.write(str(result))

input_file.close()
output_file.close()
