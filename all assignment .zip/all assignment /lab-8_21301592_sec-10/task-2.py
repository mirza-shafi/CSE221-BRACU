input_file = open("input-2.txt", 'r')
output_file = open("output-2.txt", 'w')

r1 = list(map(int, input_file.readline().strip().split(" ")))
number = r1[0]

def functionn(number):
    if number == 0:
        return 0
    if number == 1:
        return 1
    if number == 2:
        return 2
    lst = [0] * (number + 1)
    lst[1] = 1
    lst[2] = 2
    for i in range(3, number + 1):
        lst[i] = lst[i - 1] + lst[i - 2]
    return lst[number]

result = functionn(number)
output_file.write(str(result))

input_file.close()
output_file.close()
