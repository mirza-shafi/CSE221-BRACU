#Task 1(b)
input_file = open('input1b.txt', 'r')
output_file = open('output1b.txt', 'w')
N, M = list(map(int, input_file.readline().split()))

edges = []
for _ in range(M):
    info = list(map(int, input_file.readline().split(" ")))
    edges.append(info)

graph = [[] for _ in range(N + 1)]
for edge in edges:
    u, v = edge
    graph[u].append(v)

visited = [False] * (N + 1)
in_degree = [0] * (N + 1)

for u in range(len(graph)):
    for nei in graph[u]:
        in_degree[nei] += 1

queue = []
for node in range(1, N + 1):
    if in_degree[node] == 0:
        queue.append(node)

course_sequence = []
while queue:
    node = queue.pop(0)
    course_sequence.append(node)
    visited[node] = True
    for nei in graph[node]:
        in_degree[nei] -= 1
        if in_degree[nei] == 0:
            queue.append(nei)

visited[0] = True

result_str = ''
if not all(visited):
    result_str = 'IMPOSSIBLE'
else:
    result_str = ' '.join(map(str, course_sequence))

print(result_str)
output_file.write(result_str)

input_file.close()
output_file.close()
