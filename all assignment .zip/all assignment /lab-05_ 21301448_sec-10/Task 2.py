import heapq

input_file = open('input2.txt', 'r')
output_file = open('ouput2.txt', 'w')
N, M = list(map(int, input_file.readline().split()))

edges = []
for _ in range(M):
    info = list(map(int, input_file.readline().split(" ")))
    edges.append(info)

in_degree = [0] * (N + 1)
graph = [[] for _ in range(N + 1)]
for edge in edges:
    u, v = edge
    graph[u].append(v)
    in_degree[v] += 1

priority_queue = []
for i in range(1, N + 1):
    if in_degree[i] == 0:
        heapq.heappush(priority_queue, i)

course_sequence = []
while priority_queue:
    course = heapq.heappop(priority_queue)
    course_sequence.append(course)

    for neighbor in graph[course]:
        in_degree[neighbor] -= 1
        if in_degree[neighbor] == 0:
            heapq.heappush(priority_queue, neighbor)

result_str = ''
if len(course_sequence) < N:
    result_str = 'IMPOSSIBLE'
else:
    result_str = ' '.join(map(str, course_sequence))

output_file.write(result_str)
input_file.close()
output_file.close()
