input_file = open('input3.txt', 'r')
output_file = open('output3.txt', 'w')
N, M = list(map(int, input_file.readline().split()))

edges = []
for _ in range(M):
    info = list(map(int, input_file.readline().split(" ")))
    edges.append(info)

graph = [[] for _ in range(N + 1)]
reverse_graph = [[] for _ in range(N + 1)]
for edge in edges:
    u, v = edge
    graph[u].append(v)
    reverse_graph[v].append(u)

visited = [False] * (N + 1)
stack = []

def first_dfs(node, graph, visited, stack):
    visited[node] = True
    for nei in graph[node]:
        if not visited[nei]:
            first_dfs(nei, graph, visited, stack)
    stack.append(node)

for node in range(1, N + 1):
    if not visited[node]:
        first_dfs(node, graph, visited, stack)

def second_dfs(node, reverse_graph, visited, component):
    visited[node] = True
    component.append(node)
    for nei in reverse_graph[node]:
        if not visited[nei]:
            second_dfs(nei, reverse_graph, visited, component)

visited = [False] * (N + 1)
strongly_connected_components = []

while stack:
    node = stack.pop()
    if not visited[node]:
        component = []
        second_dfs(node, reverse_graph, visited, component)
        strongly_connected_components.append(component)

for component in strongly_connected_components:
    result_str = ''
    for i in component:
        result_str += str(i)+' '
    output_file.write(result_str+'\n')

input_file.close()
output_file.close()
