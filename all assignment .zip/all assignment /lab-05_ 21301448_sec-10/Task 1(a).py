input_file = open('input1a.txt', 'r')
output_file = open('output1a.txt', 'w')
N, M = list(map(int, input_file.readline().split()))

edges = []
for _ in range(M):
    u, v = list(map(int, input_file.readline().split(" ")))
    edges.append((u, v))

graph = [[] for _ in range(N + 1)]
for edge in edges:
    u, v = edge
    graph[u].append(v)

visited = [False] * (N + 1)
stack = []
currently_in_stack = [False] * (N + 1)

def dfs(node):
    visited[node] = True
    currently_in_stack[node] = True
    for nei in graph[node]:
        if currently_in_stack[nei]:
            return False  # Cycle detected
        if not visited[nei]:
            if not dfs(nei):
                return False
    currently_in_stack[node] = False
    stack.append(node)
    return True

cycle_detected = False
for node in range(1, N + 1):
    if not visited[node]:
        if not dfs(node):
            cycle_detected = True

result_str = ''
if cycle_detected:
    result_str = 'IMPOSSIBLE'
else:
    stack = stack[::-1]
    result_str = ' '.join(map(str, stack))

output_file.write(result_str)

input_file.close()
output_file.close()
